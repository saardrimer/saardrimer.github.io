Source code for the three AES designs described in

  "DSPs, BRAMs and a Pinch of Logic: New recipes for AES on FPGAs"
  by Saar Drimer, Tim G�neysu and Christof Paar.

  http://www.cl.cam.ac.uk/~sd410/papers/aes_dsp.pdf

History
=======

Version 1.1, 09-FEB-2009, corrected filename typo; put modules in separate directory with own XFLOW option files
Version 1.0, 18-MAR-2008, initial release

Contents
========

readme.txt ........... this file
license.txt .......... usage license

/basic/
aes_basic.v .......... "basic" top
aes_basic_func.v ..... "basic" AES function
aes_basic_fb_con.v ... "basic" feedback control
aes_basic.ucf ........ constraint file
aes_synth.opt ........ sythesis (-synth) XFLOW options
aes_map_par.opt ...... map and par (-implement) XFLOW options

/round/
aes_round.v .......... "round" top
aes_round_func.v ..... "round" AES function
aes_round_fb_con.v ... "round" feedback control
aes_round.ucf ........ constraint file
aes_synth.opt ........ sythesis (-synth) XFLOW options
aes_map_par.opt ...... map and par (-implement) XFLOW options

/unrolled/
aes_unrolled.v ....... "unrolled" top 
aes_unrolled_func.v .. "unrolled" main AES function
aes_unrolled_perm.v .. "unrolled" permutation control
aes_unrolled.ucf ..... constraint file
aes_synth.opt ........ sythesis (-synth) XFLOW options
aes_map_par.opt ...... map and par (-implement) XFLOW options

Usage
=====

To compile the design run the following XFLOW commands:

Basic:
  xflow -p xc5vlx30ff676-3 -synth aes_synth.opt -implement aes_map_par.opt aes_basic.v

Round:
  xflow -p xc5vlx50ff676-3 -synth aes_synth.opt -implement aes_map_par.opt aes_round.v

Unrolled:
  xflow -p xc5vsx95tff1136-3 -synth aes_synth.opt -implement aes_map_par.opt aes_unrolled.v

IMPORTANT NOTE: If you want to get the same results reported in the FCCM paper, you
must use ISE 9.2i.03 using the provided UCF files.

For more information on the design, see:
  http://www.cl.cam.ac.uk/~sd410/papers/aes_dsp.pdf

For XFLOW documentation, see Chapter 25 in:
  http://www.xilinx.com/itp/xilinx10/books/docs/dev/dev.pdf

License
=======

The source code included in this archive is provided under the following 
"Simplified BSD License" (also in license.txt):

 ----------------------------------------------------------------------------
  Copyright (c) 2008 Saar Drimer
  All rights reserved.
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.

  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE. 
 ----------------------------------------------------------------------------

Citation
========

If this code is used in academic publications, the authors would
appreciate citation of the paper describing the work.

  Saar Drimer, Tim G�neysu and Christof Paar:
  "DSPs, BRAMs and a pinch of logic: new recipes for AES on FPGAs",
  The Sixteenth Annual IEEE Symposium on Field-Programmable Custom 
  Computing Machines, April 2008.

@inproceedings{DrimerGP_NewAESRecipes_FCCM08,
  author       = {Saar Drimer and Tim G{\"{u}}neysu and Christof Paar},
  title        = {{DSPs}, {BRAMs} and a pinch of logic: new recipes for {AES} on {FPGAs}},
  booktitle    = {The Sixteenth Annual IEEE Symposium on Field-Programmable Custom Computing Machines},
  month        = {April},
  year         = {2008},
  location     = {Palo Alto, California, USA},
  publisher    = {IEEE Computer Society},
  pages        = {99-108},
  doi          = {http://doi.ieeecomputersociety.org/10.1109/FCCM.2008.42},
  address      = {Los Alamitos, CA, USA},  
  url          = {http://www.cl.cam.ac.uk/~sd410/papers/aes_dsp.pdf},
}

Contact regarding code
======================

Saar Drimer, saar.drimer@cl.cam.ac.uk, http://www.cl.cam.ac.uk/~sd410
